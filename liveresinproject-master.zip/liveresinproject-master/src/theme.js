const colors = {
  text: {
    default: "#FFF",
    reverse: "#000"
  },
  bg: {
    default: "#000",
    reverse: "#FFF"
  },
  brand: {
    red: "#FF4438",
    orange: "#FF9E18",
    tan: "#FCD199",
    blue: "#1DCAD3",
    green: "#A2D45E"
  }
};

const space = [0, 8, 16, 32, 64, 128, 256];

const fonts = {
  sans: `'Mont', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;`
};

const easings = {
  easeIn: "cubic-bezier(0.4, 0.0, 1, 1)",
  easeOut: "cubic-bezier(0.0, 0.0, 0.2, 1)",
  easeInOut: "cubic-bezier(0.4, 0.0, 0.2, 1)",
  easeInOutQuart: "cubic-bezier(0.770, 0.000, 0.175, 1.000)"
};

const theme = {
  colors,
  space,
  fonts,
  easings
};

export default theme;
