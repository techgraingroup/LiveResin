import modularScale from "src/utils/modularScale";

const unit = "px";

function space(property, value) {
  // Set environment variables
  const min = { base: 8, ratio: 2, viewportWidth: 320 };
  const max = { base: 24, ratio: 2, viewportWidth: 2560 };

  let minSize = modularScale(min.base, value, min.ratio);
  let maxSize = modularScale(max.base, value, max.ratio);

  // Transform variables
  const a = minSize;
  const b = min.viewportWidth / 100;
  const c =
    (100 * (maxSize - minSize)) / (max.viewportWidth - min.viewportWidth);

  return `
    ${property}: calc(${a}${unit} + ((1vw - ${b}${unit}) * ${c}));
    @media (min-width: ${max.viewportWidth}${unit}) {
      ${property}: ${maxSize}${unit};
    }
    @media (max-width: ${min.viewportWidth}${unit}) {
      ${property}: ${minSize}${unit};
    }
  `;
}

function fluidSpace({
  fp,
  fpx,
  fpy,
  fpt,
  fpr,
  fpb,
  fpl,
  fm,
  fmx,
  fmy,
  fmt,
  fmr,
  fmb,
  fml,
  fw,
  fh
}) {
  let finalSpace = ``;
  if (!fp) {
    if (fpt || fpy) {
      finalSpace += space("padding-top", fpy ? fpy : fpt);
    }
    if (fpb || fpy) {
      finalSpace += space("padding-bottom", fpy ? fpy : fpb);
    }
    if (fpl || fpx) {
      finalSpace += space("padding-left", fpx ? fpx : fpl);
    }
    if (fpr || fpx) {
      finalSpace += space("padding-right", fpx ? fpx : fpr);
    }
  } else {
    finalSpace += space("padding", fp);
  }
  if (!fm) {
    if (fmt || fmy) {
      finalSpace += space("margin-top", fmy ? fmy : fmt);
    }
    if (fmb || fmy) {
      finalSpace += space("margin-bottom", fmy ? fmy : fmb);
    }
    if (fml || fmx) {
      finalSpace += space("margin-left", fmx ? fmx : fml);
    }
    if (fmr || fmx) {
      finalSpace += space("margin-right", fmx ? fmx : fmr);
    }
  } else {
    finalSpace += space("margin", fm);
  }
  if (fw) {
    finalSpace += space("width", fw);
  }
  if (fh) {
    finalSpace += space("height", fh);
  }
  return finalSpace;
}

export default fluidSpace;
