import { css } from "styled-components";
import { rgba } from "polished";

const DefaultVariant = css`
  color: ${props => props.theme.colors.brand.red};
  background-color: ${props => props.theme.colors.bg.reverse};

  &:hover {
    box-shadow: 0 0 0 0.25em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 3)};
  }

  &:active {
    box-shadow: 0 0 0 0.16em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 3)};
  }

  &:focus {
    box-shadow: 0 0 0 0.33em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 3)};
  }
`;

const PrimaryVariant = css`
  color: ${props => props.theme.colors.text.default};
  background-color: ${props => props.theme.colors.brand.orange};
  transition: box-shadow 0.3s ${props => props.theme.easings.easeInOut};

  &:hover {
    box-shadow: 0 0 0 0.25em
      ${props => rgba(props.theme.colors.brand.orange, 1 / 3)};
  }

  &:hover {
    box-shadow: 0 0 0 0.16em
      ${props => rgba(props.theme.colors.brand.orange, 1 / 3)};
  }

  &:focus {
    box-shadow: 0 0 0 0.33em
      ${props => rgba(props.theme.colors.brand.orange, 1 / 3)};
  }
`;

const buttonStyles = css`
  ${props => props.variant === "default" && DefaultVariant};
  ${props => props.variant === "primary" && PrimaryVariant};
`;

export default buttonStyles;
