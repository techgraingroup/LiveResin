import React from "react";
import LastImage from "react-last-image";

import resinUltraHigh from "src/images/resin-desktop-ultra-high.png";
import resinHigh from "src/images/resin-desktop-high.png";
import resinHalf from "src/images/resin-desktop-half.png";
import resinQuarter from "src/images/resin-desktop-quarter.png";

import resinMobileHigh from "src/images/resin-mobile-high.jpg";
import resinMobileTwoThirds from "src/images/resin-mobile-two-thirds.jpg";
import resinMobileHalf from "src/images/resin-mobile-half.jpg";
import resinMobileQuarter from "src/images/resin-mobile-quarter.jpg";

import budsUltraHigh from "src/images/buds-ultra-high.jpg";
import budsHigh from "src/images/buds-high.jpg";
import budsTwoThirds from "src/images/buds-two-thirds.jpg";
import budsHalf from "src/images/buds-half.jpg";
import budsQuarter from "src/images/buds-quarter.jpg";

const imageStacks = {
  resin: {
    alt: "A spoon holding crystals of live resin",
    images: [
      {
        width: 2194,
        height: 1197,
        url: resinUltraHigh
      },
      {
        width: 1463,
        height: 798,
        url: resinHigh
      },
      {
        width: 1097,
        height: 599,
        url: resinHalf
      },
      {
        width: 548,
        height: 299,
        url: resinQuarter
      }
    ]
  },
  resinMobile: {
    alt: "A spoon holding crystals of live resin",
    images: [
      {
        width: 2669,
        height: 2552,
        url: resinMobileHigh
      },
      {
        width: 1779,
        height: 1701,
        url: resinMobileTwoThirds
      },
      {
        width: 1335,
        height: 1276,
        url: resinMobileHalf
      },
      {
        width: 667,
        height: 638,
        url: resinMobileQuarter
      }
    ]
  },
  buds: {
    alt: "A budding marijuana plant with visible resin on the surface",
    images: [
      {
        width: 2942,
        height: 3600,
        url: budsUltraHigh
      },
      {
        width: 1961,
        height: 2400,
        url: budsHigh
      },
      {
        width: 1961,
        height: 2400,
        url: budsHigh
      },
      {
        width: 1307,
        height: 1600,
        url: budsTwoThirds
      },
      {
        width: 981,
        height: 1200,
        url: budsHalf
      },
      {
        width: 490,
        height: 600,
        url: budsQuarter
      }
    ]
  }
};

const Image = ({ type, ...props }) => (
  <LastImage
    placeholder={<></>}
    images={imageStacks[type].images}
    lazy={false}
    alt={imageStacks[type].alt}
    {...props}
  />
);

export default Image;

Image.defaultProps = {
  type: "resin"
};
