import styled from "styled-components";

import { buttonStyles, fluidType } from "src/utils";

export const Wrapper = styled.button`
  position: relative;
  display: inline-block;
  width: 3em;
  height: 3em;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: 9999px;
  ${fluidType(0.75)};
  text-align: center;
  vertical-align: top;
  text-decoration: none;
  ${buttonStyles};
  cursor: pointer;
  -webkit-appearance: none;
  -moz-appearance: none;

  &:focus {
    outline: none;
  }

  > svg {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 1.5em !important;
    height: 1.5em !important;
    fill: currentColor;
    transform: translate(-50%, -50%);
    pointer-events: none;
  }
`;
