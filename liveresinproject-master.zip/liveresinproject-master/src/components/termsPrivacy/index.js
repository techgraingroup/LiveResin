import React from "react";
import styled from "styled-components";
import { rgba } from "polished";
import AriaTabPanel from "react-aria-tabpanel";
import ReactMarkDown from "react-markdown";

import { fluidType } from "src/utils";

import { Box } from "../globals";
import Panel from "../panel";

import privacyContent from "./privacy";
import termsContent from "./terms";

const MarkDownWrapper = styled.article`
  ${fluidType(0.75)};
  line-height: 1.5;
  color: ${props => props.theme.colors.text.reverse};
  a {
    text-decoration: underline;
  }
`;

const TabList = styled.ul`
  display: flex;
  flex: 1;
  margin: 0;
  padding: 0;
  padding-right: 72px;
  list-style: none;
`;

const TabListItem = styled.li`
  flex: 1;
  margin: 0;
  text-align: center;

  > div:focus {
    outline: 0;
  }
`;

function TabButton(content, tabState) {
  return (
    <div
      className={tabState.isActive ? "isActive" : ""}
      css={`
        position: relative;
        padding: 20px 0;
        ${fluidType(0.75)};
        font-weight: 900;
        line-height: 32px;
        vertical-align: middle;
        letter-spacing: 0.1em;
        text-transform: uppercase;
        color: ${props => props.theme.colors.text.default};
        background-color: ${props => props.theme.colors.bg.default};
        cursor: pointer;
        &:focus {
          outline: 0;
          background-color: ${props =>
            rgba(props.theme.colors.bg.default, 0.25)};
        }
        &.isActive {
          color: ${props => props.theme.colors.text.reverse};
          background-color: ${props => props.theme.colors.bg.reverse};
        }
      `}
    >
      {content}
    </div>
  );
}

const Tabs = () => (
  <AriaTabPanel.Wrapper letterNavigation={true}>
    <AriaTabPanel.TabList>
      <TabList className="Tabs-tablist">
        <TabListItem className="Tabs-tablistItem">
          <AriaTabPanel.Tab
            id="t1"
            className="Tabs-tab"
            letterNavigationText="terms"
          >
            {TabButton.bind(null, "Terms")}
          </AriaTabPanel.Tab>
        </TabListItem>
        <TabListItem className="Tabs-tablistItem">
          <AriaTabPanel.Tab
            id="t2"
            className="Tabs-tab"
            letterNavigationText="privacy"
          >
            {TabButton.bind(null, "Privacy")}
          </AriaTabPanel.Tab>
        </TabListItem>
      </TabList>
    </AriaTabPanel.TabList>
    <div className="Tabs-panel">
      <AriaTabPanel.TabPanel tabId="t1">
        <Box
          fpy={3}
          css={`
            height: calc(100vh - 72px);
            overflow-y: scroll;
            -webkit-overflow-scrolling: touch;
          `}
        >
          <div
            css={`
              margin-right: ${25 * 0.25}%;
              margin-left: ${25 * 0.25}%;
            `}
          >
            <MarkDownWrapper>
              <ReactMarkDown source={termsContent} />
            </MarkDownWrapper>
          </div>
        </Box>
      </AriaTabPanel.TabPanel>
      <AriaTabPanel.TabPanel tabId="t2">
        <Box
          fpy={3}
          css={`
            height: calc(100vh - 72px);
            overflow-y: scroll;
            -webkit-overflow-scrolling: touch;
          `}
        >
          <div
            css={`
              margin-right: ${25 * 0.25}%;
              margin-left: ${25 * 0.25}%;
            `}
          >
            <MarkDownWrapper>
              <ReactMarkDown source={privacyContent} />
            </MarkDownWrapper>
          </div>
        </Box>
      </AriaTabPanel.TabPanel>
    </div>
  </AriaTabPanel.Wrapper>
);

function TermsPrivacy({ showPrivacy, setShowPrivacy }) {
  return (
    <Panel showPrivacy={showPrivacy} setShowPrivacy={setShowPrivacy}>
      <Tabs />
    </Panel>
  );
}

export default TermsPrivacy;
