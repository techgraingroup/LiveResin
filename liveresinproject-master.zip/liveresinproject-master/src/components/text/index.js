import React from "react";
import styled, { css } from "styled-components";
import { color, fontWeight, textAlign } from "styled-system";

import { fluidType } from "src/utils";

const changeables = css`
  ${fontWeight};
  ${textAlign};
  ${color};
`;

const Text = styled(({ fontSize, fontWeight, textAlign, color, ...rest }) => (
  <p {...rest} />
))`
  ${changeables};
  margin: 0;
  ${props => fluidType(props.fontSize)};
  font-weight: 600;
  line-height: 1.4;
`;

Text.defaultProps = {
  fontSize: 1,
  color: "text.default"
};

export default Text;
