import React, { useState } from "react";
import AriaModal from "react-aria-modal";
import { mdiClose } from "@mdi/js";

import Icon from "../icon";

function Panel({ showPrivacy, setShowPrivacy, children }) {
  const [entered, setEntered] = useState(false);

  function close() {
    setEntered(false);
    setTimeout(() => {
      setShowPrivacy(false);
    }, 300);
  }

  return (
    <>
      <AriaModal
        titleText="menuPanel"
        onExit={close}
        onEnter={() => {
          setEntered(true);
        }}
        underlayStyle={{
          backgroundColor: entered ? "rgba(0, 0, 0, 0.5)" : "rgba(0, 0, 0, 0)",
          transition: "all 300ms ease-in-out"
        }}
        dialogStyle={{
          position: "relative",
          display: "flex",
          justifyContent: "flex-end",
          alignItems: "center",
          minHeight: "100%",
          pointerEvents: "none"
        }}
        mounted={showPrivacy}
      >
        <div
          className={entered ? "entered" : ""}
          css={`
            position: absolute;
            top: 0;
            bottom: 0;
            left 0;
            width: 100%;
            max-width: 768px;
            background-color: ${props => props.theme.colors.bg.reverse};
            overflow: hidden;
            pointer-events: all;
            transform: translate3d(-100%, 0, 0);
            transition: transform 300ms
              ${props => props.theme.easings.easeInOut};

            &.entered {
              transform: translate3d(0, 0, 0);
            }
          `}
        >
          <button
            onClick={close}
            css={`
              position: absolute;
              top: 0;
              right: 0;
              z-index: 1;
              width: 72px;
              height: 72px;
              margin: 0;
              padding: 0;
              border: 0;
              border-radius: 0;
              color: ${props => props.theme.colors.text.default};
              background: ${props => props.theme.colors.text.reverse};
              box-shadow: none;
              cursor: pointer;
              &:focus {
                outline: 0;
              }
            `}
          >
            <Icon
              symbol={mdiClose}
              size={1.5}
              color="currentColor"
              css={`
                position: absolute;
                top: 50%;
                left: 50%;
                vertical-align: top;
                transform: translate(-50%, -50%);
              `}
            />
          </button>
          {children}
        </div>
      </AriaModal>
    </>
  );
}

export default Panel;
