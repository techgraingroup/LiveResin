import { createGlobalStyle } from "styled-components";
import { normalize } from "polished";

export const GlobalStyles = createGlobalStyle`
  ${normalize()};
  *, *::before, *::after { box-sizing: border-box; }
  body {
    font-family: ${props => props.theme.fonts.sans};
    font-size: 16px;
    color: #fff;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    background-color: #000;
    overflow-x: hidden;
    overflow-y: scroll;
  }
  a {
    text-decoration: none;
    color: inherit;
  }
`;
