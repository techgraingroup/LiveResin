import styled, { keyframes } from "styled-components";

const animateHeader = keyframes`
  from {
    transform: scale3d(1, 30, 1);
  }
  to {
    transform: scale3d(1, 5, 1);
  }
`;

const animateHeaderCollapsed = keyframes`
  from {
    transform: scale3d(1, 5, 1);
  }
  to {
    transform: scale3d(1, 1, 1);
  }
`;

const animateLogo = keyframes`
  to {
    transform: scale3d(0.4, 0.4, 1);
  }
`;

const animateButton = keyframes`
  to {
    transform: translate3d(0, 0, 0);
  }
`;

export const Wrapper = styled.div`
  position: fixed;
  top: 0;
  z-index: 1001;
  display: flex;
  flex-direction: row;
  width: 100%;
  padding: 0 12.5%;
  @media (max-width: 768px) {
    padding: 0 6.25%;
  }
  height: 7.5%;
  min-height: 96px;
  @media (max-width: 640px) {
    min-height: 72px;
  }
  #logo {
    transform-origin: top left;
    &.shrink {
      animation: ${animateLogo} 1.1s
        ${props => props.theme.easings.easeInOutQuart} forwards;
    }
  }
  #register {
    transform: translate3d(0, 101%, 0);
    &.show {
      animation: ${animateButton} 500ms
        ${props => props.theme.easings.easeInOutQuart} forwards 2.2s;
    }
  }
`;

export const Color = styled.div`
  position: fixed;
  top: 0;
  z-index: 1000;
  width: 100%;
  height: 7.5%;
  min-height: 96px;
  @media (max-width: 640px) {
    min-height: 72px;
  }
  background-color: #fff;
  transform: scale3d(1, 30, 1);
  &.revealed {
    animation: ${animateHeader} 1s
      ${props => props.theme.easings.easeInOutQuart} forwards;
  }
  &.collapsed,
  &.collapsedNo {
    transform: scale3d(1, 5, 1);
    animation: ${animateHeaderCollapsed} 1.1s
      ${props => props.theme.easings.easeInOutQuart} forwards;
  }
`;
