import React from "react";
import AnchorLink from "react-anchor-link-smooth-scroll";
import { mdiArrowRight } from "@mdi/js";

import { Button, Logo } from "src/components";

import { Wrapper, Color } from "./style";

const Header = ({ state }) => (
  <>
    <Color className={state} />
    <Wrapper as="header" className={state}>
      <div
        css={`
          position: relative;
          display: flex;
          justify-content: space-between;
          align-items: center;
          width: 100%;
          height: 100%;
        `}
      >
        <div
          id="logo"
          className={
            state === "collapsed" || state === "collapsedNo" ? "shrink" : ""
          }
          css={`
            height: 100%;
          `}
        >
          <AnchorLink
            href="#intro"
            css={`
              position: absolute;
              top: 50%;
              left: 0;
              height: 50%;
              transform: translateY(-50%);
              &:focus {
                outline: none;
              }
            `}
          >
            <Logo
              showSubtext={
                state === "collapsed" || state === "collapsedNo" ? false : true
              }
            />
          </AnchorLink>
        </div>
        <div
          css={`
            overflow: hidden;
          `}
        >
          <Button
            children={`Sign up`}
            id="register"
            className={state === "collapsed" && "show"}
            as={AnchorLink}
            href="#sign-up"
            offset={96}
            variant="primary"
            iconRight={mdiArrowRight}
          />
        </div>
      </div>
    </Wrapper>
  </>
);

export default Header;
