import styled from "styled-components";
import { rgba } from "polished";

import { fluidType } from "src/utils";

export const Wrapper = styled.button`
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 100px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background-color: ${props => props.theme.colors.bg.reverse};
  cursor: pointer;
  transition: transform 200ms cubic-bezier(0.4, 0, 0.2, 1),
    box-shadow 200ms cubic-bezier(0.4, 0, 0.2, 1);

  &:hover {
    transform: scale3d(1.075, 1.075, 1);
    box-shadow: 0 0 0 0.33em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 3)};
  }

  &:active {
    transform: scale3d(0.95, 0.95, 1);
    box-shadow: 0 0 0 0.16em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 3)};
  }

  &:focus {
    outline: 0;
    box-shadow: 0 0 0 0.33em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 3)};
  }

  &::after {
    content: "";
    display: block;
    padding-bottom: 100%;
  }
`;

export const Inner = styled.div`
  margin: 0;
  ${fluidType(0.75)};
  font-weight: 900;
  line-height: 1.2;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: ${props => props.theme.colors.text.reverse};
`;
