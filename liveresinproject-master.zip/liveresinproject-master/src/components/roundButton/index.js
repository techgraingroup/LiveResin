import React from "react";

import { Wrapper, Inner } from "./style";

const RoundButton = ({ children, onClick }) => (
  <Wrapper onClick={onClick}>
    <Inner children={children} />
  </Wrapper>
);

export default RoundButton;
