import React, { useEffect } from "react";
import { keyframes } from "styled-components";

import { H1, H2, RoundButton, Text } from "src/components";
import { Box, FlexRow } from "../globals";

const animateSorry = keyframes`
  to {
    opacity: 1;
  }
`;

function Rainbow({ transitionSpeed, fullAnimation }) {
  useEffect(() => {
    let spectrum = document.getElementById("spectrum");
    let timing = 150;
    let reset = false;
    const offsetLines = function() {
      spectrum.style.strokeDashoffset = timing;

      if (timing <= 150 && !reset) {
        requestAnimationFrame(offsetLines);
        timing = timing - 1 + 3 * ((timing - 150) / 150);
      }
      if (timing > 120 && reset) {
        requestAnimationFrame(offsetLines);
        let change = 5 - 4 * ((300 - timing) / 175);
        if (change < 0.3) {
          change = 0.3;
        }
        timing = timing - change;
      }
      if (timing <= 135 && timing > 130 && reset) {
        timing -= 0.5;
        spectrum.style.opacity = 1 - (135 - timing) / 4;
      }
      if (timing <= 0) {
        timing = 300;
        reset = true;
      }
    };
    offsetLines();
  }, []);

  return (
    <svg
      viewBox="0 0 48 172"
      fill="none"
      css={`
        path {
          stroke-dasharray: 151 151;
        }
      `}
      id="spectrum"
    >
      <path
        d="M48 32H44C37.3726 32 32 37.3726 32 44V171.5"
        stroke="#FF4438"
        strokeWidth="7"
        id="rainbow1"
      />
      <path
        d="M48 25H44C33.5066 25 25 33.5066 25 44V171.5"
        stroke="#FF9E18"
        strokeWidth="7"
        id="rainbow2"
      />
      <path
        d="M48 18H44C29.6406 18 18 29.6406 18 44V171.5"
        stroke="#FCD199"
        strokeWidth="7"
        id="rainbow3"
      />
      <path
        d="M48 11H44C25.7746 11 11 25.7746 11 44V171.5"
        stroke="#1DCAD3"
        strokeWidth="7"
        id="rainbow4"
      />
      <path
        d="M48 4H44C21.9086 4 4 21.9086 4 44V171.5"
        stroke="#A2D45E"
        strokeWidth="7"
        id="rainbow5"
      />
    </svg>
  );
}

const AgeGate = ({
  setAgeVerified,
  transitioning,
  transitionSpeed,
  transitioningLock
}) => (
  <>
    <Box
      css={`
        display: flex;
        flex-direction: column;
        min-height: 100vh;
        padding-top: 50vh;
      `}
    >
      <Box
        css={`
          position: relative;
          display: flex;
          flex: 1;
          align-items: flex-start;
        `}
      >
        <Box
          fpb={3}
          css={`
            margin-right: ${25}%;
            margin-left: ${25 * 0.5}%;
            transition: opacity 300ms cubic-bezier(0.4, 0, 1, 1);
            @media (max-width: 120rem) {
              margin-right: ${25 * 0.5}%;
            }
            @media (max-width: 48rem) {
              margin-right: ${25 * 0.5}%;
            }
          `}
          style={{
            opacity: transitioning ? 0 : 1
          }}
        >
          <H1>Are you at least 21?</H1>
          <FlexRow fmt={2}>
            <Box fmr={2}>
              <RoundButton
                children={`Nope`}
                onClick={() => {
                  setAgeVerified(false);
                }}
              />
            </Box>
            <Box>
              <RoundButton
                children={`Yes`}
                onClick={() => {
                  setAgeVerified(true);
                }}
              />
            </Box>
          </FlexRow>
        </Box>
        <Box
          css={`
            position: absolute;
            top: 10%;
            left: 20%;
            right: 0;
            height: 400vh;
            z-index: 10;
            pointer-events: none;
            @media (min-aspect-ratio: 3/5) {
              left: 40%;
            }
            @media (min-aspect-ratio: 4/3) {
              left: 50%;
            }
            @media (max-width: 750px) {
              left: 20%;
            }
          `}
        >
          {transitioning && (
            <Rainbow
              transitionSpeed={transitionSpeed}
              fullAnimation={!transitioningLock}
            />
          )}
        </Box>
      </Box>
    </Box>
    {transitioningLock && (
      <Box
        css={`
          position: absolute;
          top: 155vh;
          left: 0;
          z-index: 9999;
          width: 100%;
          opacity: 0;
          animation: ${animateSorry} ${transitionSpeed / 3}ms
            cubic-bezier(0.4, 0, 1, 1) forwards ${transitionSpeed * 1.2}ms;

          @media (min-aspect-ratio: 4/3) {
            top: 245vh;
          }
          @media (max-width: 768px) {
            top: 155vh;
          }
        `}
      >
        <Box
          css={`
            position: relative;
            width: ${25}%;
            margin-right: ${25}%;
            margin-left: ${25 * 0.5}%;
            @media (max-width: 120rem) {
              width: ${25 * 1.25}%;
              margin-right: ${25 * 0.5}%;
            }
            @media (max-width: 768px) {
              width: ${25 * 3}%;
              margin-right: ${25 * 0.5}%;
            }
          `}
        >
          <H2 children={`Sorry!`} />
          <Box fmt={2} fpt={2} borderTop="1px solid white">
            <Text
              children={`The pot of gold at the end of this rainbow is only for those 21 or over! Come back once you're older.`}
            />
          </Box>
        </Box>
      </Box>
    )}
  </>
);

export default AgeGate;
