import styled, { keyframes } from "styled-components";
import { hideVisually, rgba } from "polished";

import { fluidType } from "src/utils";

const loaderAnimation = keyframes`
  0% {
    transform: translate(-50%, -50%) rotate(0deg);
  }
  100% {
    transform: translate(-50%, -50%) rotate(360deg);
  }
`;

export const Wrapper = styled.div`
  position: relative;
  display: flex;
  transition: box-shadow 0.3s ${props => props.theme.easings.easeInOut};

  &:hover {
    box-shadow: 0 0 0 0.25em
      ${props => rgba(props.theme.colors.bg.reverse, 1 / 2)};
  }

  &.focused {
    box-shadow: 0 0 0 0.25em
      ${props => rgba(props.theme.colors.bg.reverse, 2 / 3)};
  }

  @media (max-width: 80rem) {
    flex-direction: column;
  }
`;

export const CustomInput = styled.input.attrs({ type: "email" })`
  flex: 1;
  padding: 1.1em 1em 0.9em;
  border: 0;
  border-radius: 0;
  ${fluidType(1)};
  font-weight: 600;
  line-height: 1.4;
  color: ${props => props.theme.colors.brand.red};
  background-color: ${props => props.theme.colors.bg.reverse};
  transition: opacity 300ms ${props => props.theme.easings.easeInOut};

  &.processing {
    opacity: 0.7;
    cursor: wait;
  }

  &::placeholder {
    color: ${props => props.theme.colors.brand.red};
    opacity: 1;
  }

  &:focus {
    outline: none;
  }

  @media (max-width: 80rem) {
    flex: initial;
    width: 100%;
    padding: 1.4em 1em 1.3em;
    text-align: center;
  }
`;

export const Submit = styled.button`
  position: relative;
  display: inline-block;
  padding: 1.5em 2em 1.33em;
  padding-right: 4em;
  border: none;
  ${fluidType(0.75)};
  font-weight: 900;
  text-align: center;
  vertical-align: top;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  text-decoration: none;
  color: ${props => props.theme.colors.text.default};
  background-color: ${props => props.theme.colors.brand.orange};
  cursor: pointer;
  user-select: none;
  -webkit-appearance: none;
  -moz-appearance: none;

  &.processing {
    pointer-events: none;
  }

  &:focus {
    outline: none;
  }

  > span > svg {
    position: absolute;
    top: 50%;
    right: 1.5em;
    width: 1.5em !important;
    height: 1.5em !important;
    fill: currentColor;
    transform: translateY(-50%);
    pointer-events: none;
  }

  @media (max-width: 80rem) {
    width: 100%;
    /* margin-top: 1em; */
    padding: 2.25em 2em 2.08em;
    text-align: center;
  }
`;

export const HiddenLabel = styled.label`
  ${hideVisually()};
`;

export const Loader = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;
  display: inline-block;
  width: 32px;
  height: 32px;
  border: 3px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: ${loaderAnimation} 1s linear infinite;
  -webkit-animation: ${loaderAnimation} 1s linear infinite;
`;

export const CheckWrapper = styled.div`
  position: absolute;
  top: 50%;
  left: 50%;

  > svg {
    width: 1.5em !important;
    height: 1.5em !important;
    fill: currentColor;
  }
`;
