import React, { useState } from "react";
import addToMailchimp from "gatsby-plugin-mailchimp";
import { mdiArrowRight, mdiCheck } from "@mdi/js";

import { Box } from "../globals";
import Icon from "../icon";
import Text from "../text";

import {
  CustomInput,
  Submit,
  Wrapper,
  HiddenLabel,
  Loader,
  CheckWrapper
} from "./style";

function Newsletter() {
  const [focus, setFocused] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [email, setEmail] = useState("");
  const [failureMsg, setFailureMsg] = useState("");

  return (
    <form
      noValidate
      onSubmit={e => {
        if (!processing) {
          setFailureMsg("");
          e.preventDefault();
          if (!/(.+)@(.+){2,}\.(.+){2,}/.test(email)) {
            setFailureMsg(
              "Your email was entered incorrectly. Please enter a valid email to stay up-to-date."
            );
          } else {
            addToMailchimp(email).then(data => {
              if (data.result === "success") {
                setSuccess(true);
                setEmail("Thanks for signing up!");
              } else {
                setProcessing(false);
                setFailureMsg(
                  "There was a problem submitting your email. You may already be subscribed. If this issue persists, please contact us directly."
                );
              }
            });
          }
        }
      }}
    >
      <Wrapper className={focus ? "focused" : ""}>
        <>
          <HiddenLabel children={`Newsletter`} htmlFor="newsletter-input" />
          <CustomInput
            id="newsletter-input"
            placeholder={`Your email`}
            value={email}
            onChange={event => {
              setEmail(event.target.value);
            }}
            onFocus={() => {
              setFocused(true);
            }}
            onBlur={() => {
              setFocused(false);
            }}
            className={processing && "processing"}
            disabled={success}
          />
          <Submit
            type="submit"
            onFocus={() => {
              setFocused(true);
            }}
            onBlur={() => {
              setFocused(false);
            }}
            className={processing && "processing"}
            disabled={success}
          >
            <span
              style={{
                opacity: processing ? 0 : success ? 0 : 1,
                transition: "opacity 300ms ease-in-out"
              }}
            >
              Sign up
              <Icon symbol={mdiArrowRight} />
            </span>
            <Loader
              style={{
                opacity: processing ? 1 : 0,
                transition: "opacity 300ms ease-in-out"
              }}
            />
            <CheckWrapper
              style={{
                opacity: success ? 1 : 0,
                transform: success
                  ? "scale(1,1) translate(-50%, -50%)"
                  : "scale(0,0) translate(-50%, -50%)",
                transition: "all 300ms ease-in-out"
              }}
            >
              <Icon
                symbol={mdiCheck}
                style={{
                  width: "1.5em !important",
                  height: "1.5em !important"
                }}
              />
            </CheckWrapper>
          </Submit>
        </>
      </Wrapper>
      <Box fpy={1}>{failureMsg && <Text fontSize={1}>{failureMsg}</Text>}</Box>
    </form>
  );
}

export default Newsletter;
