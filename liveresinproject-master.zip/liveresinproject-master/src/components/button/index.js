import React from "react";
import PropTypes from "prop-types";

import Icon from "../icon";

import { Wrapper } from "./style";

const Button = ({ children, iconLeft, iconRight, variant, ...rest }) => (
  <Wrapper
    iconLeft={iconLeft}
    iconRight={iconRight}
    variant={variant}
    {...rest}
  >
    {iconLeft && <Icon symbol={iconLeft} />}
    {children}
    {iconRight && <Icon symbol={iconRight} />}
  </Wrapper>
);

Button.propTypes = {
  iconLeft: PropTypes.object,
  iconRight: PropTypes.object,
  children: PropTypes.string.isRequired,
  variant: PropTypes.string.isRequired
};

Button.defaultProps = {
  children: "Button",
  variant: "default"
};

export default Button;
