import styled, { css } from "styled-components";

import { buttonStyles, fluidType } from "src/utils";

export const Wrapper = styled.button`
  position: relative;
  display: inline-block;
  padding: 1.5em 2em 1.33em;
  border: none;
  ${fluidType(0.75)};
  font-weight: 900;
  text-align: center;
  vertical-align: top;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  text-decoration: none;
  ${buttonStyles};
  cursor: pointer;
  user-select: none;
  -webkit-appearance: none;
  -moz-appearance: none;

  &:focus {
    outline: none;
  }

  > svg {
    position: absolute;
    top: 50%;
    width: 1.5em !important;
    height: 1.5em !important;
    fill: currentColor;
    transform: translateY(-50%);
    pointer-events: none;
  }

  ${props =>
    props.iconLeft &&
    css`
      padding-left: 4em;

      > svg:first-of-type {
        left: 1.5em;
      }
    `};

  ${props =>
    props.iconRight &&
    css`
      padding-right: 4em;

      > svg:last-of-type {
        right: 1.5em;
      }
    `};
`;
