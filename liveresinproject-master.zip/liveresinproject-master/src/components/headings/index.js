import React from "react";
import styled, { css } from "styled-components";
import { color, textAlign } from "styled-system";

import { fluidType } from "src/utils";

const changeables = css`
  ${textAlign};
  ${color};
`;

export const H1 = styled(({ children, color, textAlign, ...rest }) => (
  <h1 children={children} {...rest} />
))`
  ${changeables};
  margin: 0;
  ${fluidType(5)};
  font-weight: 900;
  line-height: 1;
  letter-spacing: -0.02em;
`;

H1.defaultProps = {
  color: "text.default"
};

export const H2 = styled(({ children, color, textAlign, ...rest }) => (
  <h2 children={children} {...rest} />
))`
  ${changeables};
  margin: 0;
  ${fluidType(4)};
  font-weight: 900;
  line-height: 1;
  letter-spacing: -0.02em;
`;

H2.defaultProps = {
  color: "text.default"
};

export const H3 = styled(({ children, color, textAlign, ...rest }) => (
  <h3 children={children} {...rest} />
))`
  ${changeables};
  margin: 0;
  ${fluidType(3)};
  font-weight: 900;
  line-height: 1;
  letter-spacing: -0.02em;
`;

H3.defaultProps = {
  color: "text.default"
};

export const H4 = styled(({ children, color, textAlign, ...rest }) => (
  <h4 children={children} {...rest} />
))`
  ${changeables};
  margin: 0;
  ${fluidType(2)};
  font-weight: 900;
  line-height: 1;
  letter-spacing: -0.02em;
`;

H4.defaultProps = {
  color: "text.default"
};

export const H5 = styled(({ children, color, textAlign, ...rest }) => (
  <h5 children={children} {...rest} />
))`
  ${changeables};
  margin: 0;
  ${fluidType(1)};
  font-weight: 900;
  line-height: 1;
  letter-spacing: -0.02em;
`;

H5.defaultProps = {
  color: "text.default"
};

export const H6 = styled(({ children, color, textAlign, ...rest }) => (
  <h6 children={children} {...rest} />
))`
  ${changeables};
  margin: 0;
  ${fluidType(0.75)};
  font-weight: 900;
  line-height: 1.2;
  letter-spacing: 0.1em;
  text-transform: uppercase;
`;

H6.defaultProps = {
  color: "text.default"
};
