import React, { useState, useEffect } from "react";
import { Watch } from "scrollmonitor-react";
import { mdiFacebook, mdiInstagram } from "@mdi/js";

import { Box, H2, H6, IconButton, Newsletter, Text } from "src/components";

function TextBlock({
  fixed,
  isFullyInViewport,
  isBelowViewport,
  showPrivacy,
  setShowPrivacy
}) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!show && !fixed) {
      setShow(true);
    }
  }, [isBelowViewport, isFullyInViewport]);

  return (
    <>
      <Box
        css={`
          width: ${25}%;
          margin-right: ${25}%;
          margin-left: ${25 * 0.5}%;
          transition: opacity 300ms cubic-bezier(0.4, 0, 1, 1),
            transform 1s cubic-bezier(0, 0, 0.2, 1);
          @media (max-width: 120rem) {
            width: ${25 * 1.25}%;
            margin-right: ${25 * 0.5}%;
          }
          @media (max-width: 48rem) {
            width: ${25 * 3}%;
            margin-right: ${25 * 0.5}%;
          }
        `}
        style={{
          opacity: show ? 1 : 0,
          transform: show ? "translate3d(0,0,0)" : "translate3d(0,30px,0)"
        }}
      >
        <H2 children={`Now live in CA.`} />
      </Box>
      <Box
        css={`
          display: flex;
          flex-wrap: wrap;
        `}
      >
        <Box
          css={`
            width: ${25}%;
            margin-right: ${25}%;
            margin-left: ${25 * 0.5}%;
            transition: opacity 300ms cubic-bezier(0.4, 0, 1, 1),
              transform 1s cubic-bezier(0, 0, 0.2, 1);
            @media (max-width: 120rem) {
              width: ${25 * 1.25}%;
              margin-right: ${25 * 0.5}%;
            }
            @media (max-width: 48rem) {
              width: ${25 * 3}%;
              margin-right: ${25 * 0.5}%;
            }
          `}
          style={{
            opacity: show ? 1 : 0,
            transform: show ? "translate3d(0,0,0)" : "translate3d(0,30px,0)"
          }}
        >
          <Box fmt={2} fpt={2} fpb={2} borderTop="1px solid white">
            {/* <Text
              children={`Sign up here to stay up-to-date on our upcoming retail locations.`}
            /> */}
            {/* <h2 style={{marginTop:40}}>Available at</h2> */}
            <Text>
              <ul style={{listStyleType:'none',padding:0}}>
              <li><h3 style={{marginBottom:10}}>Los Angeles</h3></li>
              <li>Cookies Melrose</li>
              <li>Cookies Maywood</li>
              <li>Dr. Green Thumbs Sylmar</li>
              <li>Dr. Green Thumbs Los Angeles</li>
              <li>Caña Harbor</li>
              <li>Caña Sylmar</li>
              <li><h3 style={{marginBottom:10}}>Oakland</h3></li>
              <li>Magnolia Oakland</li>
              <li>Irie Care Delivery</li>
              <li><h3 style={{marginBottom:10}}>Bay Area</h3></li>
              <li>Dr. Green Thumbs San Francisco</li>
              <li>Dr. Green Thumbs Sacramento</li>
              <li>Dr. Green Thumbs Humboldt</li>
              <li>West Coast Premium Medz - Walnut Creek</li>
              <li>Highway 29 Health Care - Vallejo</li>
              </ul>
            </Text>
          </Box>
        </Box>
        <Box
          css={`
            width: ${25}%;
            margin-right: ${25 * 0.5}%;
            @media (max-width: 120rem) {
              width: ${25 * 1.25}%;
            }
            @media (max-width: 48rem) {
              width: ${25 * 3}%;
              margin-left: ${25 * 0.5}%;
            }
          `}
        >
          <Box fmt={2}>
          <Text
              children={`Sign up here to stay up-to-date on our upcoming retail locations.`}
              style={{marginBottom:40}}
            />
            <Newsletter />
            <Box
              fmt={2}
              css={`
                display: flex;
                flex-direction: row;
                justify-content: start;
                @media (max-width: 48rem) {
                  justify-content: center;
                  margin-top: 48px;
                }
              `}
            >
              <Box fmr={1}>
                <IconButton
                  title="Facebook"
                  icon={mdiFacebook}
                  as="a"
                  href="https://www.facebook.com/LiveResinProject/"
                  target="_blank"
                  rel="noopener noreferrer"
                />
              </Box>
              <IconButton
                title="Instagram"
                icon={mdiInstagram}
                as="a"
                href="https://www.instagram.com/liveresinproject/"
                target="_blank"
                rel="noopener noreferrer"
              />
            </Box>
          </Box>
        </Box>
      </Box>
      <Box
        css={`
          width: ${25}%;
          margin-right: ${25}%;
          margin-left: ${25 * 0.5}%;
          transition: opacity 300ms cubic-bezier(0.4, 0, 1, 1),
            transform 1s cubic-bezier(0, 0, 0.2, 1);
          @media (max-width: 120rem) {
            width: ${25 * 1.25}%;
            margin-right: ${25 * 0.5}%;
          }
          @media (max-width: 48rem) {
            width: ${25 * 3}%;
            margin-right: ${25 * 0.5}%;
          }
        `}
        style={{
          opacity: show ? 1 : 0,
          transform: show ? "translate3d(0, 0, 0)" : "translate3d(0, 30px, 0)"
        }}
      >
        <Box
          fmt={3}
          tabIndex={0}
          css={`
            cursor: pointer;
            &:focus {
              outline: none;
            }
            @media (max-width: 48rem) {
              margin-top: 48px;
              text-align: center;
            }
          `}
          onKeyDown={e => {
            if (e.which === 13) {
              setShowPrivacy(!showPrivacy);
            }
          }}
        >
          <H6
            children={`Privacy and Terms`}
            onClick={() => {
              setShowPrivacy(!showPrivacy);
            }}
            css={`
              position: relative;
              display: inline-block;
              &::before {
                content: "";
                position: absolute;
                width: 100%;
                height: 2px;
                bottom: -2px;
                left: 0;
                background-color: #fff;
                visibility: hidden;
                transform: scaleX(0);
                transition: all 0.3s ease-in-out 0s;
              }
              &:hover::before {
                visibility: visible;
                transform: scaleX(1);
              }
            `}
          />
        </Box>
        {showPrivacy && (
          <Box fpy={3}>
            <Box fmb={1.5}>
              <Text
                children={
                  "We will be launching a portfolio of concentrate and vape products in California soon. Sign up here to stay up-to-date on our upcoming launch schedule and retail locations."
                }
              />
            </Box>
            <Text
              children={
                "We will be launching a portfolio of concentrate and vape products in California soon. Sign up here to stay up-to-date on our upcoming launch schedule and retail locations."
              }
            />
          </Box>
        )}
      </Box>
    </>
  );
}

const WatchedTextBlock = Watch(TextBlock);

function Form({ fixed, showPrivacy, setShowPrivacy }) {
  return (
    <Box
      as="section"
      id="sign-up"
      fpy={4.5}
      bg="brand.red"
      css={`
        display: flex;
        flex-direction: column;
        justify-content: center;
      `}
    >
      <WatchedTextBlock
        fixed={fixed}
        privacy={showPrivacy}
        setShowPrivacy={setShowPrivacy}
      />
    </Box>
  );
}

export default Form;
