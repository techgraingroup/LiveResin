import React, { useState, useEffect } from "react";
import { keyframes } from "styled-components";

import { Box, H2, Text, Image } from "src/components";

const openingAnimation = keyframes`
  to {
    transform: translate3d(0,0%,0)
  }
`;

function Intro({ fixed, transitionSpeed }) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!fixed) {
      setShow(true);
    }
  }, [fixed]);

  return (
    <Box
      as="section"
      id="intro"
      fpy={4.5}
      css={`
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        min-height: 100vh;
        overflow: hidden;
      `}
    >
      <Box
        fpb={3}
        css={`
          position: absolute;
          top: -52%;
          height: 100%;
          width: 100%;
          left: 0;
          display: flex;
          align-items: flex-end;
          margin-left: auto;
          user-select: none;
          transform: translate3d(0, 150%, 0);
          animation: ${openingAnimation} ${transitionSpeed * 1.25}ms forwards;
          &::after {
            content: "";
            position: absolute;
            top: 87%;
            left: -5%;
            z-index: -1;
            width: 100%;
            height: 100%;
            background-color: #000;
          }
          @media (min-aspect-ratio: 3/5) {
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: ${100 - 25 - 12.5}%;
            &::after {
              height: 30%;
            }
          }
          @media (max-width: 768px) {
            top: -40%;
            right: initial;
            bottom: initial;
            left: 0;
            width: 100%;
            &::after {
              height: 100%;
            }
          }
          @media (max-width: 640px) {
            top: -47%;
          }
          @media (max-width: 512px) {
            top: -52%;
          }
          @media (max-width: 375px) {
            top: -55%;
          }
          @media (max-width: 320px) {
            top: -60%;
          }
        `}
      >
        <Image
          type="resin"
          imgStyle={{
            objectPosition: "left center"
          }}
        />
      </Box>
      <Box
        css={`
          position: relative;
          width: ${25}%;
          margin-right: ${25}%;
          margin-left: ${25 * 0.5}%;
          transition: opacity 300ms cubic-bezier(0.4, 0, 1, 1),
            transform 1s cubic-bezier(0, 0, 0.2, 1);
          opacity: ${show ? 1 : 0};
          transform: ${show ? "translate3d(0,0,0)" : "translate3d(0,30px,0)"};
          @media (max-width: 120rem) {
            width: ${25 * 1.33}%;
            margin-right: ${25 * 0.5}%;
          }
          @media (max-width: 768px) {
            width: ${25 * 3}%;
            margin-right: ${25 * 0.5}%;
          }
          @media (max-width: 768px) {
            margin-top: ${80}%;
          }
          @media (max-width: 640px) {
            margin-top: ${80}%;
          }
        `}
      >
        <H2 children={`Adventures in extraction.`} />
        <Box fmt={2} fpt={2} borderTop="1px solid white">
       
          <Text
            children={`Our goal is to transport people to another time and place, where they truly feel the essence of a living cannabis plant. We are exposing the world to cannabis in it’s most flavorful form. Like rare wines or culinary delicacies, live resin can replicate even the finest of sensory experiences.`}
          />
        </Box>
      </Box>
    </Box>
  );
}

export default Intro;
