import React, { useState, useEffect } from "react";
import { Watch } from "scrollmonitor-react";

import { Box, Image } from "src/components";

function Outro({ fixed, isInViewport, isBelowViewport }) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!show && !fixed) {
      setShow(true);
    }
  }, [isBelowViewport, isInViewport]);

  return (
    <Box
      as="section"
      id="outro"
      css={`
        position: relative;
        width: 100%;
        height: 125vh;
        overflow: hidden;
        background-color: ${props => props.theme.colors.bg.default};
        &::after {
          content: "";
          position: absolute;
          right: 0;
          bottom: 0;
          left: 0;
          z-index: 1;
          height: 75%;
          background: linear-gradient(
            to bottom,
            hsla(0, 0%, 0%, 0) 0%,
            hsla(0, 0%, 0%, 0.013) 8.1%,
            hsla(0, 0%, 0%, 0.049) 15.5%,
            hsla(0, 0%, 0%, 0.104) 22.5%,
            hsla(0, 0%, 0%, 0.175) 29%,
            hsla(0, 0%, 0%, 0.259) 35.3%,
            hsla(0, 0%, 0%, 0.352) 41.2%,
            hsla(0, 0%, 0%, 0.45) 47.1%,
            hsla(0, 0%, 0%, 0.55) 52.9%,
            hsla(0, 0%, 0%, 0.648) 58.8%,
            hsla(0, 0%, 0%, 0.741) 64.7%,
            hsla(0, 0%, 0%, 0.825) 71%,
            hsla(0, 0%, 0%, 0.896) 77.5%,
            hsla(0, 0%, 0%, 0.951) 84.5%,
            hsla(0, 0%, 0%, 0.987) 91.9%,
            hsl(0, 0%, 0%) 100%
          );
          pointer-events: none;
        }
      `}
    >
      <Image
        type="buds"
        style={{
          minHeight: "100%",
          opacity: show ? 1 : 0,
          transform: show ? "scale3d(1,1,1)" : "scale3d(1.1,1.1,1.1)",
          transition: `opacity 300ms cubic-bezier(0.4, 0, 1, 1) 300ms,
          transform 1.4s cubic-bezier(0, 0, 0.2, 1) 300ms`
        }}
      />
    </Box>
  );
}

export default Watch(Outro);
