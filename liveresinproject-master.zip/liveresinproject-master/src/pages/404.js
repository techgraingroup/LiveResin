import React from "react";
import { Link } from "gatsby";

import { FlexCol, Box, SEO, H1, Button } from "src/components";

const NotFoundPage = () => (
  <>
    <SEO title="404: Page not found" keywords={[`lost`, `404`, `empty`]} />
    <FlexCol
      minHeight="100vh"
      justifyContent="center"
      alignItems="center"
      fpy={4.5}
    >
      <H1 children={`404: Page not found.`} textAlign="center" />
      <Box fmt={4}>
        <Button
          children={`Take me back to the good stuff`}
          variant="primary"
          as={Link}
          to="/"
        />
      </Box>
    </FlexCol>
  </>
);

export default NotFoundPage;
