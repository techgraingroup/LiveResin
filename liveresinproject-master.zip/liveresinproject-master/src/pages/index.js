import React, { useState, useEffect } from "react";

import { AgeGate, Header, SEO, TermsPrivacy } from "src/components";

import Intro from "./_sections/_intro";
import Form from "./_sections/_form";
import Outro from "./_sections/_outro";

import resinUltraHigh from "src/images/resin-desktop-ultra-high.png";
import resinHigh from "src/images/resin-desktop-high.png";
import resinHalf from "src/images/resin-desktop-half.png";
import resinQuarter from "src/images/resin-desktop-quarter.png";

const transitionSpeed = 2000;

function Index() {
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(true);
  const [fixed, setFixed] = useState(true);
  const [transitioning, setTransitioning] = useState(false);
  const [transitioningLock, setTransitioningLock] = useState(false);
  const [ageVerified, setAgeVerified] = useState(undefined);

  useEffect(() => {
    if (ageVerified === true) {
      setTransitioning(true);
      setTimeout(() => {
        setFixed(false);
      }, transitionSpeed * 1.15);
    }
    if (ageVerified === false) {
      setTransitioningLock(true);
    }
  }, [ageVerified]);

  return (
    <>
      <SEO
        title="Live Resin Project - Adventures In Extraction From The Inventors of Live Resin"
        description="We are the inventors of live resin, the true essence of cannabis - our pot of gold. As originators of this evolved cannabis extraction process, our sole focus is to deliver unparalleled quality and flavor from each unique plant."
      />
      <Header
        state={
          transitioning
            ? "collapsed"
            : transitioningLock
            ? "collapsedNo"
            : imageLoaded
            ? "revealed"
            : "open"
        }
      />
      <div
        style={
          fixed
            ? {
                position: "fixed",
                width: "100%",
                height: "100%",
                overflow: "hidden"
              }
            : {}
        }
      >
        <div
          style={{
            position: "absolute",
            transform:
              transitioning || transitioningLock
                ? "translate3d(0,-50%,0)"
                : "translate3d(0,0,0)",
            // opacity: transitioning ? 0 : 1,
            transition:
              "transform " +
              (transitionSpeed / 3) * 1.75 +
              "ms cubic-bezier(0.4, 0.0, 1, 1)"
          }}
          css={`
            height: 225vh;
            width: 100%;
            @media (min-aspect-ratio: 4/3) {
              height: 400vh;
            }
          `}
        >
          <AgeGate
            setAgeVerified={setAgeVerified}
            transitioning={transitioning || transitioningLock}
            transitioningLock={transitioningLock}
            transitionSpeed={transitionSpeed}
          />
        </div>
        <div
          style={{
            position: fixed ? "fixed" : "",
            height: fixed ? "100%" : "",
            width: "100%",
            // transform: transitioning
            //   ? "translate3d(0,0,0)"
            //   : "translate3d(0,100%,0)",
            // // opacity: transitioning ? 1 : 0,
            // transition:
            //   "transform " +
            //   transitionSpeed / 1.3 +
            //   "ms cubic-bezier(0.4, 0, 1, 1)",
            pointerEvents: fixed ? "none" : "all"
          }}
        >
          {transitioning && (
            <main>
              <Intro fixed={fixed} transitionSpeed={transitionSpeed} />
              <Form
                fixed={fixed}
                privacy={showPrivacy}
                setShowPrivacy={setShowPrivacy}
              />
              <Outro fixed={fixed} />
            </main>
          )}
        </div>
      </div>
      <img
        class="last-image"
        src={resinQuarter}
        srcset={`${resinQuarter} 512w, ${resinHalf} 1024w, ${resinHigh} 1024w, ${resinUltraHigh} 2048w`}
        sizes="(min-width: 800px) 50vw, 100vw"
        alt="A spoon holding crystals of live resin"
        style={{
          display: "none"
        }}
        onLoad={() => {
          setImageLoaded(true);
        }}
      />
      <TermsPrivacy showPrivacy={showPrivacy} setShowPrivacy={setShowPrivacy} />
    </>
  );
}

export default Index;
