const siteUrl = `https://www.liveresinproject.com`;

module.exports = {
  siteMetadata: {
    title: `Live Resin Project`,
    description: `We are the inventors of live resin, the true essence of cannabis - our pot of gold. As originators of this evolved cannabis extraction process, our sole focus is to deliver unparalleled quality and flavor from each unique plant.`,
    author: `@liveresinproject`,
    siteUrl: siteUrl
  },
  plugins: [
    `gatsby-plugin-polyfill-io`,
    `gatsby-plugin-react-helmet`,
    `gatsby-transformer-sharp`,
    `gatsby-plugin-sharp`,
    `gatsby-plugin-sri`,
    `gatsby-plugin-root-import`,
    `gatsby-plugin-favicon`,
    `gatsby-plugin-sitemap`,
    `gatsby-plugin-robots-txt`,
    {
      resolve: `gatsby-plugin-styled-components`,
      options: {
        displayName: false
      }
    },
    {
      resolve: `gatsby-source-filesystem`,
      options: {
        name: `images`,
        path: `${__dirname}/src/images`
      }
    },
    {
      resolve: `gatsby-plugin-manifest`,
      options: {
        name: `Live Resin Project`,
        short_name: `LRP`,
        start_url: `/`,
        background_color: `#fff`,
        theme_color: `#000`,
        display: `minimal-ui`,
        icon: `src/favicon.png`
      }
    },
    {
      resolve: `gatsby-plugin-layout`,
      options: {
        component: require.resolve(`${__dirname}/src/components/layout`)
      }
    },
    {
      resolve: `gatsby-plugin-canonical-urls`,
      options: {
        siteUrl: siteUrl
      }
    },
    {
      resolve: "gatsby-plugin-mailchimp",
      options: {
        endpoint:
          "https://liveresinproject.us20.list-manage.com/subscribe/post?u=a9b2379f2c417bfd3ff38efd9&amp;id=6faa4727e8"
      }
    },
    {
      resolve: `gatsby-plugin-google-tagmanager`,
      options: {
        id: "GTM-5STN343",
        includeInDevelopment: false
      }
    }
  ]
};
