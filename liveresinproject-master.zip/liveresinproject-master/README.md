# Field's Gatsby Starter

To install run:

```sh
    # create a new Gatsby site using the default starter
    npx gatsby new gatsby-field-starter https://github.com/fieldmedialab/gatsby-starter
```

For more support on this project, or if you are reaching out to take over this codebase, reach out to us at info@builtbyfield.com. We can help.
